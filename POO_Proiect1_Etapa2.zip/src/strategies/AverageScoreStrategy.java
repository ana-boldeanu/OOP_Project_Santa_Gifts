package strategies;

public interface AverageScoreStrategy {
    /**
     * Returns the averageScore of the Child
     */
    Double getScore();
}
