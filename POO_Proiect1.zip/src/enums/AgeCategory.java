package enums;

public enum AgeCategory {
    BABY,
    KID,
    TEEN,
    YOUNG_ADULT
}
